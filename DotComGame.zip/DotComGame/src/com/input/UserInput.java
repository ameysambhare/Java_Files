package com.input;

import java.util.Scanner;

public class UserInput {
	
	public String getUserInput() {
		Scanner sc = new Scanner(System.in);
		return sc.next();
	}

}
